
export const environment = {
  production: false,
  backendUrl: '//localhost:15318',
  devProviders: []
};