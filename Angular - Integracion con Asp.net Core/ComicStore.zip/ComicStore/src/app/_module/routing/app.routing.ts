import { NgModule } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

//aca van el import de los routing de las paginas

@NgModule({
    imports: [
        CommonModule,
        BrowserModule
        //aca van los routings de las paginas
    ],
    exports: [

    ],
})
export class AppRoutingModule { }