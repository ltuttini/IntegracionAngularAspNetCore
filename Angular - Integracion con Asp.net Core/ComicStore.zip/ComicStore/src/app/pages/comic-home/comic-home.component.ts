import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comic-home',
  templateUrl: './comic-home.component.html',
  styleUrls: ['./comic-home.component.css']
})
export class ComicHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
