export const environment = {
  production: true,
  backendtUrl: 'https://localhost:4200',
  devProviders: []
};
