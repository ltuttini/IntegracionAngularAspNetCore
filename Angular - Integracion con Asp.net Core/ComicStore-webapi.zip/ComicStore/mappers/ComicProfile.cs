﻿using AutoMapper;
using ComicStore.Dtos;
using ComicStore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComicStore.mappers
{
    public class ComicProfile : Profile
    {
        public ComicProfile()
        {
            CreateMap<Comic, ComicDto>()
                .ForMember(d=>d.Id, o=>o.MapFrom(x=>x.ComicId))
                .ReverseMap();
        }
    }
}
