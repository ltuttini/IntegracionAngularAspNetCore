﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ComicStore.Dtos;
using ComicStore.Model;
using ComicStore.Service;
using Microsoft.AspNetCore.Mvc;

namespace ComicStore.Controllers
{
    [Route("api/[controller]")]
    public class ComicController : Controller
    {
        private readonly IComicService _comicService;
        private readonly IMapper _mapper;

        public ComicController(IMapper mapper, IComicService comicService)
        {
            _mapper = mapper;
            _comicService = comicService;
        }

        [HttpGet]
        public async Task<List<ComicDto>> GetAll()
        {
            var comics = await _comicService.GetAll();

            return _mapper.Map<List<ComicDto>>(comics);
        }

        //[HttpGet]
        //public IActionResult GetAll()
        //{
        //    var comics = _comicService.GetAll();
        //    return Ok(comics);
        //}

        [HttpGet("{comicId:int}")]
        public async Task<ComicDto> Get(int comicId)
        {
            var comic = await _comicService.GetById(comicId);

            return _mapper.Map<ComicDto>(comic);
        }

        [HttpGet("{title}/filter")]
        public async Task<List<ComicDto>> GetByTitle(string title)
        {
            var comics = await _comicService.GetByTitle(title);

            return _mapper.Map<List<ComicDto>>(comics);
        }

        //[HttpPost]
        //public void Post([FromBody]ComicDto comic)
        //{
        //    var entity = _mapper.Map<Comic>(comic);

        //    _comicService.Save(entity);
        //}

        [HttpPost]
        public async Task Post([FromBody]ComicDto comic)
        {
            var entity = _mapper.Map<Comic>(comic);

            await _comicService.Save(entity);
        }

        [HttpPut]
        public async Task Update([FromBody]ComicDto comic)
        {
            var entity = _mapper.Map<Comic>(comic);

            await _comicService.Update(entity);
        }

    }
}