﻿using ComicStore.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Reflection;

namespace ComicStore.Data
{
    public class ComicStoreContext : DbContext
    {
        public ComicStoreContext()
            : base()
        { }

        public ComicStoreContext(DbContextOptions<ComicStoreContext> options)
            : base(options)
        { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured)
                return;

            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
            var connectionString = configuration.GetConnectionString("ComicStore");
            optionsBuilder.UseSqlServer(connectionString);

        }

        public DbSet<Comic> Comics { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.ApplyConfiguration(new ComicConfig());

        }
    }

    public class ComicConfig : IEntityTypeConfiguration<Comic>
    {
        public void Configure(EntityTypeBuilder<Comic> builder)
        {
            builder.Property(x => x.Title).HasColumnType("varchar(100)");
            builder.Property(x => x.Description).HasColumnType("varchar(2000)");
            builder.Property(x => x.Author).HasColumnType("varchar(100)");

            builder.Property(x => x.Price).HasColumnType("decimal(18,2)");
            builder.Property(x => x.StarRating).HasColumnType("tinyint");

            builder.Property(x => x.ImageUrl).HasColumnType("varchar(100)");

            //var comics = new Comic[]
            //{
            //    new Comic() { Title = "Infinity Gauntlet", Author ="ED BRUBAKER", Description ="...", Price = 540, PublishDate = DateTime.Now.AddMonths(-8), StarRating = 4, ImageUrl = "img/InfinityGauntlet.jpg" }
            //};

            //builder.HasData(comics);
        }
    }
}
