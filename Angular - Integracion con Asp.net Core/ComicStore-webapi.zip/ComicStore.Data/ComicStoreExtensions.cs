﻿using ComicStore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ComicStore.Data
{
    public static class ComicStoreExtensions
    {
        public static void SeedData(this ComicStoreContext context)
        {
            if (!context.Comics.Any())
            {
                var comics = new Comic[]
                {
                    new Comic() {
                        Title = "Infinity Gauntlet",
                        Author ="ED BRUBAKER",
                        Description ="El Demente Titán busca agraciar a la Muerte asesinando a la mitad del Universo. Para lograrlo, se embarca en la misión de buscar las seis Gemas del Infnito, dispersas a través de la galaxia, y reunirlas en el Guantelete del Infnito. ¿Podrán los máximos héroes de Marvel hacerle frente a un Dios?",
                        Price = 540,
                        PublishDate = DateTime.Now.AddMonths(-8),
                        StarRating = 4,
                        ImageUrl = "img/InfinityGauntlet.jpg"
                    },
                    new Comic() {
                        Title = "Batman: A Celebration of 75 Years",
                        Author ="Varios",
                        Description ="...",
                        Price = 1200,
                        PublishDate = DateTime.Now.AddYears(-2),
                        StarRating = 3,
                        ImageUrl = "img/BatmanCelebration75Years.jpg"
                    },
                    new Comic() {
                        Title = "Amazing Spider-Man 01",
                        Author ="Slott",
                        Description ="...",
                        Price = 450,
                        PublishDate = DateTime.Now.AddYears(-1),
                        StarRating = 3,
                        ImageUrl = "img/AmazingSpiderMan01.jpg"
                    },
                    new Comic() {
                        Title = "DeadPool: Mala Sangre",
                        Author ="Rob Liefeld",
                        Description ="...",
                        Price = 390,
                        PublishDate = DateTime.Now.AddMonths(-2),
                        StarRating = 2,
                        ImageUrl = "img/DeadPoolMalaSangre.jpg"
                    },
                    new Comic() {
                        Title = "Avengers era de Ultron: Batalla en Equipo",
                        Author ="",
                        Description ="...",
                        Price = 150,
                        PublishDate = DateTime.Now.AddYears(-1),
                        StarRating = 2,
                        ImageUrl = "img/AvengersUltron.jpg"
                    }
                };

                context.Comics.AddRange(comics);
                context.SaveChanges();
            }


        }
    }

}
