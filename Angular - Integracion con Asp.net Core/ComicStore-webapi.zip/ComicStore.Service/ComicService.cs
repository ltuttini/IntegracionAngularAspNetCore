﻿using ComicStore.Data;
using ComicStore.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComicStore.Service
{
    public class ComicService : IComicService
    {
        private readonly ComicStoreContext _dbContext;
        public ComicService(ComicStoreContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<Comic>> GetAll()
        {
            return await _dbContext.Comics.ToListAsync();
        }

        public async Task<Comic> GetById(int comicId)
        {
            return await _dbContext.FindAsync<Comic>(comicId);
        }

        public async Task<List<Comic>> GetByTitle(string title)
        {
            return await _dbContext.Comics.Where(x=>x.Title.Contains(title)).ToListAsync();
        }

        //public List<Comic> GetAll()
        //{
        //    return _dbContext.Comics.ToList();
        //}

        //public void Save(Comic entity)
        //{
        //    _dbContext.AddAsync(entity);
        //    _dbContext.SaveChangesAsync();
        //}

        public async Task Save(Comic entity)
        {
            await _dbContext.AddAsync(entity);
            await _dbContext.SaveChangesAsync();
        }

        public async Task Update(Comic entity)
        {
            _dbContext.Update(entity);
            await _dbContext.SaveChangesAsync();
        }

    }
}
