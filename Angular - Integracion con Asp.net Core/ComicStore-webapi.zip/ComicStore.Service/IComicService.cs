﻿using ComicStore.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ComicStore.Service
{
    public interface IComicService
    {
        //List<Comic> GetAll();
        Task<List<Comic>> GetAll();
        Task<Comic> GetById(int comicId);
        Task<List<Comic>> GetByTitle(string title);
        //void Save(Comic entity);
        Task Save(Comic entity);
        Task Update(Comic entity);
    }
}