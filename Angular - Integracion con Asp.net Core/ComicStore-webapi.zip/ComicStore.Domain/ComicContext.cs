﻿using System;

namespace ComicStore.Domain
{
    public class ComicContext
    {

    }
}
